//
//  LoginVC.swift
//  MvvmSimpleLogin
//
//  Created by Hamza Mustafa on 29/11/2021.
//

import UIKit

class LoginVC: UIViewController {
    
    @IBOutlet weak var labelMsg: UILabel!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passTextField: UITextField!
    
    // declaring var for accessing View Model methods
    var authenticationVM = AuthenticationVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.labelMsg.isHidden = true
    }
    
    @IBAction func loginBtTapped(_ sender: UIButton) {
        if let email = emailTextField.text, let pass = passTextField.text {
            authenticationVM.authenticateUserWith(email, pass)
            authenticationVM.loginCompletionHandler { [weak self] (status, message) in
                
                if status {
                    self?.labelMsg.isHidden = false
                    self?.labelMsg.text = "Logged in:\(String(describing: self?.authenticationVM.user.email)))"
                }
                else{
                    self?.labelMsg.isHidden = false
                    self?.labelMsg.text = message
                }
            }
        }
    }
}
