//
//  AuthenticationVM.swift
//  MvvmSimpleLogin
//
//  Created by Hamza Mustafa on 29/11/2021.
//

import Foundation
import UIKit

class AuthenticationVM : NSObject {
    
    var user: User!
    var email: String { return user.email}
    
    //completion
    typealias authLoginCallBack = (_ status: Bool, _ message: String) -> Void
    var loginCallBack: authLoginCallBack?
   
    func authenticateUserWith(_ email:String, _ pass:String) {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.2) {
            if email.count != 0 {
                if pass.count != 0 {
                    self.verifyUserWith(email, pass)
                } else {
                    // pass empty
                    self.loginCallBack?(false,"Password field is empty")
                }
            } else{
                // email empty
                self.loginCallBack?(false,"Email field is empty")
            }
        }
    }
    
    fileprivate func verifyUserWith(_ email: String,_ password: String) {
        if email == "hamza@gmail.com" && password == "123" {
            user = User(email: email)
            self.loginCallBack?(true,"User is correct")
        }
        else {
            // invalid crededentials
            self.loginCallBack?(false,"Invalid Crededentials")
        }
    }
    
    // Completion Handler
    func loginCompletionHandler(completion: @escaping authLoginCallBack) {
        self.loginCallBack = completion
    }
}
