//
//  User.swift
//  MvvmSimpleLogin
//
//  Created by Hamza Mustafa on 29/11/2021.
//

import Foundation

struct User {
    var email: String
}
